# Aparat Live Chat - Android Studio Project

این پروژه یک برنامه اندرویدی ساده برای نمایش صفحه چت لایو آپارات است.

## لینک پیش‌فرض
https://aparat.com/dark_batman/live/chat

## اجرا
1. پروژه را در Android Studio باز کنید.
2. صبر کنید Gradle Sync کامل شود.
3. از منوی Build گزینه Build APK(s) را انتخاب کنید.
4. APK در مسیر زیر ساخته می‌شود:
   app/build/outputs/apk/debug/app-debug.apk

## نکته
این نسخه صفحه رسمی چت آپارات را داخل WebView نمایش می‌دهد. دریافت مستقیم و پردازش پیام‌های چت به‌صورت API/Socket جداگانه نیاز به بررسی سازوکار فعلی چت آپارات دارد.
